# GardenAPP

La aplicación GardenApp tiene algunos errores que deben ser corregidos:

1- En la lista no se muestra correctamente la imagen de cada planta (2 puntos)

2- No importa que planta seleccione siempre se accede a la misma (2 puntos)

3- El buscador no muestra ningun resultado (2 puntos)

4- Los textos donde deberian mostrarse los cuidados de la planta no son correctos (2 puntos)

5- El color de la barra de navegacion en el detalle no es el correcto (2 puntos)
