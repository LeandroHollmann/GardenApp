package com.istea.gardenapp.ui.theme

import androidx.compose.ui.graphics.Color

val Teal700 = Color(0xFF00796B)
val Teal500 = Color(0xFF009688)
val Teal200 = Color(0xFF03DAC5)
val White = Color(0xFFFFFFFF)
val LightGray = Color(0xFFDDDDDD)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)